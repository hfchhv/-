#ifndef __USERONENET_H
#define	__USERONENET_H

#include "cjson.h"
#define ONENET_THING_PROPERTY_POST   "$sys/L85llcpy9e/text1/thing/property/post"  
#define ONENET_PROPERTY_SET_TOPIC   {"$sys/L85llcpy9e/text1/thing/property/set"}



void Upload_SensorData_ToOneNET(void);
//订阅主题的时候需要在while循环前面调用这个函数OneNet_Subscribe(devSubTopic, 1);
//此函数需要在循环里面调用，对下发的json进行解析
void OneNET_SubscribePropertySet(void);
//解析json需要执行的逻辑，在void OneNet_RevPro(unsigned char *cmd)内部调用
void OneNET_ExecutePropertySet(cJSON *params_json);



#endif 
