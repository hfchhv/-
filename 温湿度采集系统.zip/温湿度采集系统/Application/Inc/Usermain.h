#ifndef __USERMAIN_H
#define	__USERMAIN_H



void UserMain(void);
void UserWhile(void);



#endif 
