#include "stm32f1xx_hal.h"
#include "useronenet.h"
#include "string.h"
#include "stdio.h"
#include "dht11.h"
#include "onenet.h"
#include "esp8266.h"
#include "gpio.h"

const char devPubTopic[] = ONENET_THING_PROPERTY_POST;
const char *devSubTopic[] = ONENET_PROPERTY_SET_TOPIC;


extern DHT11_Data_TypeDef Data;

char PUBLIS_BUF[256];

static uint32_t s_lastReportTime = 0; 

unsigned char* dataptr=NULL;

uint8_t Alarm_flag;


/**
 * @brief   上报温湿度数据到OneNET平台（物模型属性上报）
 * @param   无
 * @retval  无
 * @note    从DHT11读取温湿度，封装成JSON格式，通过MQTT发布到OneNET
 */
void Upload_SensorData_ToOneNET(void)
{
	
	
	memset(PUBLIS_BUF, 0, sizeof(PUBLIS_BUF));
	
	snprintf(PUBLIS_BUF  , sizeof(PUBLIS_BUF ), "{\"id\":\"123\",\"params\":{\"Temp\":{\"value\":%d},\"Hum\":{\"value\":%d} }}",
					Data.temp_int,Data.humi_int);
	
	//每五秒发送一次
	uint32_t currentTime = HAL_GetTick();  
    
    
   if ((currentTime - s_lastReportTime) >= 5000)  
   {
        s_lastReportTime = currentTime;  
        OneNet_Publish(devPubTopic, PUBLIS_BUF);
	
				ESP8266_Clear();
   }
    
    
    
    HAL_Delay(1);  
	
}

void OneNET_SubscribePropertySet(void)
{
		dataptr = ESP8266_GetIPD(1000);
		if(dataptr != NULL)
		{
			OneNet_RevPro(dataptr );
		}
		HAL_Delay(5); 
}

void OneNET_ExecutePropertySet(cJSON *params_json)
{
		cJSON *led_json,*Alarm_json;
		led_json = cJSON_GetObjectItem(params_json,"LED");
		Alarm_json = cJSON_GetObjectItem(params_json,"Alarm");
	
		if(led_json != NULL)
		{
			if(led_json->type == cJSON_True) 
			{
					LED_ON();
			}
			else 
			{
					LED_OFF();
			}
		}
		if(Alarm_json != NULL)
		{
			if(Alarm_json->type == cJSON_True) 
			{
					Alarm_flag = 1;
													
			}
			else 
			{
					Alarm_flag = 0;
											
			}
			
		}	
}
