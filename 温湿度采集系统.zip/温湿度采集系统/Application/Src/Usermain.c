#include "stm32f1xx_hal.h"
#include "usermain.h"
#include "oled.h"
#include "dht11.h"
#include "dwt_delay.h"
#include "stdio.h"
#include "key.h"
#include "tim.h"
#include "gpio.h"
#include "esp8266.h"
#include "onenet.h"
#include "string.h"
#include "useronenet.h"

extern uint8_t  Alarm_flag;

DHT11_Data_TypeDef Data;
char Temp[16],oled_temp_th[16];
char Hum[16],oled_Hum_th[16];

uint8_t Temp_TH =30;
uint8_t Hum_TH = 70;

extern const char *devSubTopic[];

uint8_t Keynum1;

typedef enum {
		main,					
		Temp_set,
		Hum_set,
}DisplayState;

DisplayState currentstate = main ;

void oled_showmain(void)
{
	OLED_Printf(0,0,8,"温湿度采集系统"); 
	
	if(DHT11_Read_TempAndHumidity( &Data))
	{
		snprintf(Temp , sizeof(Temp), "Temp:%d.%d", Data.temp_int,Data.temp_deci);
		OLED_Printf(0,16,8,"%s",Temp); 
		snprintf(Hum , sizeof(Hum), "Hum :%d.%d", Data.humi_int,Data.humi_deci);
		OLED_Printf(0,32,8,"%s",Hum); 
	}
	OLED_Update(); 
}

void oled_show_Temp_set(void)
{
	 
	OLED_Printf(32,0,8,"温度阈值");
	
	if(Keynum1 == 2)
	{
		if(Temp_TH < 100)
		{
			Temp_TH ++;
		}
	}
	else if(Keynum1 == 3)
	{
		if(Temp_TH > 0)
		{
			Temp_TH --;
		}
	}
	snprintf(oled_temp_th  , sizeof(oled_temp_th ), "Temp_TH:%d",Temp_TH);
	OLED_Printf(0,16,8,"%s",oled_temp_th );
	OLED_Update(); 	
}

void oled_show_Hum_set(void)
{
	
	OLED_Printf(32,0,8,"湿度阈值");
	
	if(Keynum1 == 2)
	{
		if(Hum_TH < 100)
		{
			Hum_TH ++;
		}
	}
	else if(Keynum1 == 3)
	{
		if(Hum_TH > 0)
		{
			Hum_TH --;
		}
	}
	snprintf(oled_Hum_th  , sizeof(oled_Hum_th ), "Hum_TH:%d",Hum_TH);
	OLED_Printf(0,16,8,"%s",oled_Hum_th ); 
	OLED_Update(); 
}

void oled_switch(void)
{
	Keynum1 =Key_GetNum();
	if(Keynum1 == 1)
	{
		OLED_Clear(); 
		currentstate = (DisplayState)((currentstate+1) % 3);
	}
	switch(currentstate)
	{
		case main:
				 oled_showmain();
				 break;
		case Temp_set:
				 oled_show_Temp_set();
				 break;
		case Hum_set:
				 oled_show_Hum_set();
				 break;
		
	}
}

void Alarm_Statue(void)
{
	if(Alarm_flag ==1)
	{
		if(Data.temp_int > Temp_TH ||  Data.humi_int > Hum_TH  )
		{
			Alarm_ON(); 
		}
		else
		{
			Alarm_OFF(); 
		}
	}
	else
	{
		Alarm_OFF(); 
	}
	
}



void UserMain(void)
{
		HAL_TIM_Base_Start_IT(&htim2); 
		DWT_Init();
		DHT11_Init();
		OLED_Init();
		
		OLED_Printf(0,0,8,"网络连接中");
		OLED_Update(); 
		ESP8266_STA_Init();
		while(OneNet_DevLink())//连接Onenet平台,如果失败等待500ms继续尝试。
		{
			DWT_Delay_ms(500); 
		}
		OLED_Clear();
		OLED_Printf(0,0,8,"连接成功");
		OLED_Update(); 
		DWT_Delay_ms(1000); 
		OneNet_Subscribe(devSubTopic, 1);
}

void UserWhile(void)
{
	Upload_SensorData_ToOneNET();	
	OneNET_SubscribePropertySet();
	oled_switch();
	Alarm_Statue();
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
   
    if (htim->Instance == TIM2) 
    {
				
				Key_Tick(); 
    }
}
