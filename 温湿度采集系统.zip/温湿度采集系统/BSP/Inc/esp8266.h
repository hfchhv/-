#ifndef __ESP8266_H
#define __ESP8266_H

#include "stm32f1xx_hal.h"
/* 定义缓冲区长度 */
#define UART_RX_BUFF_LEN 512


/**
  * @brief  ESP8266 网络工作模式枚举类型
  */
typedef enum{
    STA,        // 站点模式（Station），ESP8266 作为客户端连接 Wi-Fi
    AP,         // 接入点模式（Access Point），ESP8266 作为热点
    STA_AP      // 站点+接入点模式，同时作为客户端和热点
} ENUM_Net_ModeTypeDef;

/**
  * @brief  ESP8266 连接模式枚举类型
  */
typedef enum {
    SINGLE_CONN  = 0,  // 单连接模式，一次只能建立一个 TCP/UDP 连接
    MULTI_CONN   = 1  // 多连接模式，可同时建立多个 TCP/UDP 连接
} ENUM_ConnModeTypeDef;

/**
  * @brief  ESP8266 传输模式枚举类型
  */
typedef enum {
    TRANSPARENT_OFF = 0,  // 普通模式
    TRANSPARENT_ON  = 1   // 透传模式
} ENUM_TransparentModeTypeDef;


/**
  * @brief STA模式参数
  */
#define      macUser_ESP8266_ApSsid                       "nnhhnn"         		//要连接的热点的名称
#define      macUser_ESP8266_ApPwd                        "12345678"           	//要连接的热点的密钥

#define      macUser_ESP8266_TcpServer_IP                 "mqtts.heclouds.com"     //要连接的服务器的 IP
#define      macUser_ESP8266_TcpServer_Port               1883              		//要连接的服务器的端口

void ESP8266_SendData(unsigned char *data, unsigned short len);
uint8_t ESP8266_Test(void);
void ESP8266_STA_Init(void);
unsigned char *ESP8266_GetIPD(unsigned short timeOut);
void ESP8266_Clear(void);

#endif 
