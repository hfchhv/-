  #include "DWT_Delay.h" 

/**
  * @brief  初始化DWT计数器
  * @param  无
  * @retval 无
  * @note   使用延时函数前，必须调用本函数
  */
void DWT_Init(void)
{
		CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk; //使能DWT,第24位置1
   
		DWT->CYCCNT = 0;  /* DWT CYCCNT寄存器计数清0 */ //使能CYCCNT寄存器之前，先清0
   
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;  /* 使能Cortex-M DWT CYCCNT寄存器 第零位置1*/
    
}

/**
  * @brief  DWT计数实现精确延时，32位计数器
  * @param  time : 延迟长度，单位1 us
  * @retval 无
  * @note   无
  */
void DWT_Delay_us(uint32_t time)
{
    /* 将微秒转化为对应的时钟计数值*/
    uint32_t tick_duration= time * (SystemCoreClock / 1000000) ;
    uint32_t tick_start = (uint32_t)DWT->CYCCNT;         /* 刚进入时的计数器值 */
    
    while(((uint32_t)DWT->CYCCNT) - tick_start < tick_duration);
	

}

/**
  * @brief  DWT计数实现精确延时，32位计数器
  * @param  time : 延迟长度，单位1 ms
  * @retval 无
  */
void DWT_Delay_ms(uint32_t time)
{
    for(uint32_t i = 0; i < time; i++)
    {
        DWT_Delay_us(1000);
    }
}


/**
  * @brief  DWT计数实现精确延时，32位计数器
  * @param  time : 延迟长度，单位1 S
  * @retval 无
  */
void DWT_Delay_s(uint32_t time)
{
    for(uint32_t i = 0; i < time; i++)
    {
        DWT_Delay_ms(1000);
    }
}

/*********************************************END OF FILE**********************/

