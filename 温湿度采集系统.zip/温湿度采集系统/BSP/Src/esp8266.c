#include "esp8266.h"
#include "string.h"
#include "usart.h"
#include "stdio.h"




uint8_t ESP8266_RxBuff[UART_RX_BUFF_LEN];    // ESP8266串口接收缓冲
uint8_t  ESP_RX_Complete=0;


/**
 * @brief  向 ESP8266 发送字符串数据（常用于 AT 指令）
 * @param  str 待发送的字符串
 * @retval None
 */
void ESP8266_SendString(char *str)
{
    /* 直接调用 HAL 库串口发送，阻塞方式 */
    HAL_UART_Transmit(&huart3, (uint8_t *)str, strlen(str),HAL_MAX_DELAY);
}

/**
  * @brief  等待 ESP8266 响应，带超时和条件判断
  * @param  timeout_ms: 超时时间（毫秒）
  * @param  expected_str: 期望的字符串，如果为 NULL 则只等待任何响应
  * @param  clear_flag: 是否在返回前清除标志位
  * @retval 1 表示成功（收到期望响应），0 表示失败/超时
  */
uint8_t ESP8266_WaitResponse(uint32_t timeout_ms, const char *expected_str)
{
    uint32_t tick_start = HAL_GetTick();
    
    while(HAL_GetTick() - tick_start < timeout_ms)
    {
        if(ESP_RX_Complete)
        {
            ESP8266_RxBuff[UART_RX_BUFF_LEN - 1] = '\0';
            
            printf("%s\r\n",ESP8266_RxBuff);
            // 检查是否包含期望的字符串
            if(strstr((char *)ESP8266_RxBuff, expected_str) != NULL)
            {
                ESP_RX_Complete = 0;
                return 1;
            }
						
            
            // 未匹配到，清除标志继续等待
            ESP_RX_Complete = 0;
						
        }
				
    }
    
    // 超时，确保标志位被清除
    ESP_RX_Complete = 0;
		
    return 0;
}


/**
  * @brief  设置 ESP8266 为发送数据模式（AT+CIPSEND）
  * @note   调用此函数后 ESP8266 进入发送数据模式，等待数据发送指令
  * @retval 1 表示成功，0 表示失败
  */
uint8_t ESP8266_SetSendMode(uint16_t len)
{
    
     
		
		ESP8266_Clear();
		// 格式化 AT 指令：在结尾添加回车换行
    char buf[248];
    snprintf(buf, sizeof(buf), "AT+CIPSEND=%d\r\n", len);
		
    // 发送指令到 ESP8266
    ESP8266_SendString(buf);
   return  ESP8266_WaitResponse(3000,">");
    
}

/**
  * @brief  清空 ESP8266 接收缓冲区
  */
void ESP8266_Clear(void)
{
    memset(ESP8266_RxBuff, 0, UART_RX_BUFF_LEN);
    ESP_RX_Complete = 0;
}


/**
  * @brief  向 ESP8266 发送指定长度的数据（支持二进制）
  * @param  data: 数据指针
  * @param  len: 数据长度
  * @retval None
  */
void ESP8266_SendData(unsigned char *data, unsigned short len)
{
    
		
		if(ESP8266_SetSendMode( len))
		{
			HAL_UART_Transmit(&huart3, (uint8_t *)data, len, HAL_MAX_DELAY);
		}
		
			 
		
		
   
}




/**
  * @brief  发送 AT 指令到 ESP8266 并等待发送完成
  * @note   本函数只负责发送，不检查 ESP8266 的响应
  * @param  cmd: 要发送的 AT 指令字符串
  * @retval None
  */
void ESP8266_Cmd(const char *cmd)
{
	
		ESP8266_Clear();
		// 格式化 AT 指令：在结尾添加回车换行
    char buf[128];
    snprintf(buf, sizeof(buf), "%s\r\n", cmd);
		
    // 发送指令到 ESP8266
    ESP8266_SendString(buf);
		
	
		
}


/**
  * @brief  测试 ESP8266 模块是否可用
  * @retval 0 表示失败，1 表示成功
  */
uint8_t ESP8266_Test(void)
{
		
    // 发送 AT 指令，检测模块是否响应
    ESP8266_Cmd("AT");
	
		return  ESP8266_WaitResponse(2000,"OK");
    
}


void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    
    if(huart->Instance == USART3)  // ESP8266 数据到达
    {		
			
			 ESP_RX_Complete=1;
			
			// 重新开启 ESP8266 DMA 接收
			HAL_UARTEx_ReceiveToIdle_DMA(&huart3, ESP8266_RxBuff, UART_RX_BUFF_LEN); 
			
    }

		
}

/**
  * @brief  UART 错误回调函数
  * @note   当 UART 出现错误时触发
  *         - USART3: 清除错误标志，并重新开启 DMA 接收
  * @param  huart: UART 句柄指针
  * @retval 无
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3)
    {
        // 清除帧错误标志
        __HAL_UART_CLEAR_FEFLAG(huart);

        // 重新启动 ESP8266 DMA 接收
        HAL_UARTEx_ReceiveToIdle_DMA(&huart3, ESP8266_RxBuff, UART_RX_BUFF_LEN);
    }
}

/**
  * @brief  ESP8266 软件复位并等待 ready
  * @retval 1 表示复位完成，0 表示超时
  */
uint8_t ESP8266_SoftReset_WaitReady(void)
{
    // 发送软复位指令 AT+RST
    ESP8266_Cmd("AT+RST");
        
   return  ESP8266_WaitResponse(5000,"OK");

}


/**
  * @brief  设置 ESP8266 工作模式
  * @param  mode: 工作模式枚举类型 (STA/AP/STA+AP)
  * @retval 0 表示失败，1 表示成功
  */
uint8_t ESP8266_SetMode(ENUM_Net_ModeTypeDef mode)
{
    char *cmd;   // 定义 AT 指令字符串指针

    // 根据传入的模式选择对应 AT 指令
    switch(mode)
    {
        case STA:    
            cmd = "AT+CWMODE=1";   // 设置为 STA 模式
            break;
        case AP:     
            cmd = "AT+CWMODE=2";   // 设置为 AP 模式
            break;
        case STA_AP: 
            cmd = "AT+CWMODE=3";   // 设置为 STA+AP 模式
            break;
        default:     
            return 0;              // 非法模式参数，返回失败
    }

    // 发送设置模式指令
    ESP8266_Cmd(cmd); 
    return  ESP8266_WaitResponse(1000,"OK");
		
    
}


/**
  * @brief  设置 ESP8266 连接模式（单连接或多连接）
  * @param  mode: SINGLE_CONN 或 MULTI_CONN
  * @retval 1 表示成功，0 表示失败
  */
uint8_t ESP8266_SetConnMode(ENUM_ConnModeTypeDef mode)
{
    /* 定义发送指令缓冲区 */
    char *cmd;

    /* 根据模式选择指令
       SINGLE_CONN: 单连接模式
       MULTI_CONN: 多连接模式 */
    if(mode == SINGLE_CONN)
        cmd = "AT+CIPMUX=0";
    else
        cmd = "AT+CIPMUX=1";

    /* 发送设置指令*/
    ESP8266_Cmd(cmd);
		return  ESP8266_WaitResponse(1000,"OK");

    
    
}


/**
  * @brief  连接指定 Wi-Fi
  * @param  ssid: Wi-Fi 名称
  * @param  password: Wi-Fi 密码
  * @retval 0 表示失败，1 表示成功
  */
uint8_t ESP8266_ConnectWiFi(const char *ssid, const char *password)
{
    char cmd[128];                                          // 定义发送指令缓冲区
    snprintf(cmd, sizeof(cmd), "AT+CWJAP=\"%s\",\"%s\"", ssid, password); // 构造连接 Wi-Fi 指令

    // 发送连接指令
   ESP8266_Cmd(cmd);
	
    return  ESP8266_WaitResponse(8000,"OK"); 
    
}


/**
  * @brief  通过 ESP8266 连接到 TCP 服务器
  * @note   根据是否为多连接模式，选择是否使用连接编号
  * @param  ip: 服务器 IP 地址
  * @param  port: 服务器端口
  * @param  conn_id: 连接编号（多连接模式有效，单连接模式忽略，取值 0~4）
  * @retval 1 表示连接成功，0 表示连接失败或超时
  */
uint8_t ESP8266_ConnectTCPServer(const char *ip, uint16_t port, uint8_t conn_id)
{
    /* 定义 AT 指令缓冲区 */
    char cmd[128];

    /* ESP8266 最多支持 5 个连接，编号范围 0~4
       编号非法直接返回失败 */
    if(conn_id > 4) return 0;

    /* 根据连接编号生成 AT 指令
       conn_id = 0: 单连接模式
       conn_id > 0: 多连接模式 */
    if(conn_id == 0)
        snprintf(cmd, sizeof(cmd), "AT+CIPSTART=\"TCP\",\"%s\",%d", ip, port);
    else
        snprintf(cmd, sizeof(cmd), "AT+CIPSTART=%d,\"TCP\",\"%s\",%d", conn_id, ip, port);

    
    ESP8266_Cmd(cmd);
		return  ESP8266_WaitResponse(5000,"OK"); 
		
          
}

/**
  * @brief  设置 ESP8266 透传模式
  * @note   根据 mode 参数选择开启或关闭透传模式
  * @param  mode: TRANSPARENT_OFF 关闭透传模式
  *               TRANSPARENT_ON  开启透传模式
  * @retval 1 表示设置成功，0 表示失败
  */
uint8_t ESP8266_SetTransparentMode(ENUM_TransparentModeTypeDef mode)
{
    /* 定义 AT 指令缓冲区 */
    char *cmd;

    /* 根据模式生成 AT 指令
       TRANSPARENT_OFF: 关闭透传模式
       TRANSPARENT_ON:  开启透传模式 */
    if(mode == TRANSPARENT_OFF)
        cmd = "AT+CIPMODE=0";
    else
        cmd = "AT+CIPMODE=1";

    
    ESP8266_Cmd(cmd);
		return  ESP8266_WaitResponse(1000,"OK");
    

    
    
}



/**
  * @brief  启用 ESP8266 STA 模式的 DHCP
  * @note   让 ESP8266 从路由器自动获取 IP 地址
  * @retval 1 表示成功，0 表示失败
  */
uint8_t ESP8266_SetDHCP(void)
{
    // 发送启用 DHCP 指令（STA 模式）
    ESP8266_Cmd("AT+CWDHCP=1,1");
    
    // 等待响应，超时 2 秒
    return ESP8266_WaitResponse(2000, "OK");
}


/**
  * @note  ESP8266 透传模式说明：
  *        - 透传模式开启后，模块会直接将 TCP/UDP 数据透传到 UART。
  *        - 透传模式的结束指令为 "+++"。
  *        - 在不使用透传模式时，需要发送 "+++" 结束透传模式，否则下一次上电时 ESP8266 仍然处于透传模式。
  *        - 为避免忘记关闭透传模式导致问题，可以先发送 "+++" 关闭透传模式，
  *          然后发送 "AT+SAVETRANSLINK=0"，这样下一次上电后不会自动进入透传模式。
  *        - 如果希望每次上电都自动进入透传模式，可以发送 "AT+SAVETRANSLINK=1"。
  *        - 在透传模式下，AT 命令会被限制，部分命令需要退出透传模式才能执行。
  */

/**
  * @brief  ESP8266 任务函数
  * @note   完成 ESP8266 上电初始化、模式设置、Wi-Fi 连接、TCP 连接及透传模式配置
  * @retval 无
  */
void ESP8266_STA_Init(void)
{
    
   HAL_UARTEx_ReceiveToIdle_DMA(&huart3, ESP8266_RxBuff, UART_RX_BUFF_LEN);  
	ESP8266_Test();
  ESP8266_SoftReset_WaitReady();
	ESP8266_SetConnMode(SINGLE_CONN);
	ESP8266_SetMode(STA);
	ESP8266_SetDHCP();
	ESP8266_ConnectWiFi(macUser_ESP8266_ApSsid, macUser_ESP8266_ApPwd);
	ESP8266_ConnectTCPServer(macUser_ESP8266_TcpServer_IP, macUser_ESP8266_TcpServer_Port, 0);
//	ESP8266_SetTransparentMode(TRANSPARENT_ON);
//	ESP8266_SetSendMode();
	
	
        
}



/**
  * @brief  获取平台返回的数据
  * @param  timeOut: 超时时间（毫秒）
  * @retval 接收到的数据指针，NULL 表示超时
  */
unsigned char *ESP8266_GetIPD(unsigned short timeOut)
{
    

		char *ptrIPD = NULL;
    
	if(	ESP8266_WaitResponse(timeOut , "IPD,"))
	{
		
			HAL_Delay(10); 
			ptrIPD = strstr((char *)ESP8266_RxBuff, "IPD,");
			if(ptrIPD != NULL)
			{
				
				
				ptrIPD = strchr(ptrIPD, ':');							//找到':'
				if(ptrIPD != NULL)
				{
					ptrIPD++;
					return (unsigned char *)(ptrIPD);
				}
				else{return NULL;}
				
			}
			else{return NULL;}
					
	}
    
    return NULL;
}



